const cadastrar = document.getElementById("cadastrar");

function validar() {
    var nomedisco = document.getElementById("nomevinil").value;
    var erronomedisco = document.getElementById("errovinil");
    var nomeartista = document.getElementById("nomeartista").value;
    var erroartista = document.getElementById("erroartista");
    var anolanc = document.getElementById("anolanc").value;
    var erroanolanc = document.getElementById("erroanolanc");
    var dataaquisicao = document.getElementById("dataaquisicao").value;
    var errodata = document.getElementById("errodata");
    var precocompra = document.getElementById("precocompra").value;
    var erroprecocompra = document.getElementById("erroprecocompra");
    var precovenda = document.getElementById("precovenda").value;
    var erroprecovenda = document.getElementById("erroprecovenda");

    erronomedisco.textContent = "";
    erroartista.textContent = "";

    if (nomedisco == "") {
       erronomedisco.textContent = "Nome do vinil deve ser digitado";
    }

    if (nomeartista.length <2) {
        erroartista.textContent = "Deve ter pelo menos 2 caracteres";
    }

    if (anolanc =="") {
        erroanolanc.textContent = "Digite o ano de lançamento";
    }
    if (parseInt(anolanc)<1900) {
        erroanolanc.textContent = "Digite o ano a partir de 1900";
    }
    
    validardata(dataaquisicao);

    if (parseFloat(precocompra)<0) {
        erroprecocompra.textContent = "Valor deve ser informado";
    }
    if (parseFloat(precovenda)<10 || parseFloat(precovenda>1000)) {
        erroprecovenda.textContent = "Valor deve ser de 10 a 1000 reais";
    }

}

function validardata(vdata) {
   var dia = parseInt(vdata[0]+vdata[1]);
   var mes = parseInt(vdata[3]+vdata[4]);
   var ano = parseInt(vdata[6]+vdata[7]+vdata[8]+vdata[9]);
   if (dia < 1 || dia > 31) {
       errodata.textContent = "Dia Inválido";
   }
   if (mes <1 || mes > 12) {
       errodata.textContent = "Mês inválido";
   }
   if (dia==31 && (mes==2 || mes==4 || mes==6 || mes== 9 || mes==11 )) {
       errodata.textContent = "Dia 31 inválido para o mês";
   }
   if (dia==30 && mes==2) {
       errodata.textContent = "Dia 30 inválido para fevereiro";
   }
   // ano bissexto
   var fator1 = ano % 4;
   var fator2 = ano % 100;
   var fator3 = ano % 400;
   var bissexto = 0;
   if (fator1 == 0 && fator2 != 0 || fator3 == 0) {
       bissexto = 1;
   }
   if (dia==29 && mes == 2 && bissexto == 0) {
       errodata.textContent = "29/fev inválido. Não é ano bissexto";
   }
}

cadastrar.addEventListener("click", validar);
